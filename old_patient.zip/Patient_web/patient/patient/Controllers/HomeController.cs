﻿using System.Linq;
using System.Web.Mvc;
using PatientInformationSystem.Models;

namespace PatientInformationSystem.Controllers
{
    public class HomeController : Controller
    {
        private PatientDBContext db = new PatientDBContext();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(Patient patient)
        {
            if (ModelState.IsValid)
            {
                var existingPatient = db.Patients.FirstOrDefault(p => p.EmailAddress == patient.EmailAddress || p.PhoneNumber == patient.PhoneNumber);
                if (existingPatient == null)
                {
                    db.Patients.Add(patient);
                    db.SaveChanges();
                    ViewBag.Message = "Data Saved Successfully";
                }
                else
                {
                    ViewBag.Message = "Patient with the same Email or Phone Number already exists.";
                }
            }

            return View(patient);
        }
    }
}
